<?php
$GLOBALS['config']['for_test'] = 'only_for_test';

$GLOBALS['config']['default_mod'] = 'default';
$GLOBALS['config']['default_action'] = 'index';

$GLOBALS['config']['site_name'] = 'LazyPHP';
$GLOBALS['config']['on_sae'] = true;

$GLOBALS['config']['cookie_time'] = 60*60*24;
$GLOBALS['config']['cookie_path'] = '/';








?>